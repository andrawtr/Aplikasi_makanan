package com.example.menumakanan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<String> FotoMakanan = new ArrayList<>();
    private ArrayList<String> NamaMakanan = new ArrayList<>();
    private ArrayList<String> InfoMakanan = new ArrayList<>();
    private ArrayList<String> HargaMakanan = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getDataFromInternet();
    }

    private void prosesRecyclerViewAdapter(){
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(FotoMakanan, NamaMakanan, InfoMakanan, HargaMakanan,this);

        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
    private void getDataFromInternet(){
        NamaMakanan.add("Mie ayam");
        FotoMakanan.add("https://selerasa.com/wp-content/uploads/2015/05/images_mie_Mie_ayam_14-mie-ayam-kampung.jpg");
        InfoMakanan.add("Makanan yang sangat popular di Indonesia bahkan di dunia adalah Mie ayam. Mie ayam merupakan makanan yang paling banyak dijual di Indonesia karna makanan yang begitu simple sehingga bisa dinikmati banyak orang.");
        HargaMakanan.add("Harga : Rp 15.000");

        NamaMakanan.add("Nasi Goreng");
        FotoMakanan.add("https://www.masakapahariini.com/wp-content/uploads/2019/11/shutterstock_1067156342-780x440.jpg");
        InfoMakanan.add("Nasi goreng merupakan makanan simple yang Hampir bisa dimasak orang orang karna rasanya yang enak seluruh dunia pun mengakui bahwa makanan nasi goreng adalah termasuk makanan yang enak  .");
        HargaMakanan.add("Harga : Rp 20.000");

        NamaMakanan.add("Nasi Ayam");
        FotoMakanan.add("https://cdn2.tstatic.net/travel/foto/bank/images/nasi-ayam.jpg");
        InfoMakanan.add("Nasi ayam yang berasal dari semarang, makanan yang terdiri dari nasi kuah opor dan ada suwiran ayam yang nikmat.");
        HargaMakanan.add("Harga : Rp 10.000");

        NamaMakanan.add("Nasi Ayam Hainan");
        FotoMakanan.add("https://delishtube.com/wp-content/uploads/2017/02/Nasi-Ayam-Hainan.jpg");
        InfoMakanan.add("Ayam hainan merupakan hidangan yang berasal dari provinsi Hainan di China, namun hidangan ini menjadi sangat populer di kawasan Asia Tenggara, khusunya Singapura.");
        HargaMakanan.add("Harga : Rp 25.000");

        NamaMakanan.add("Sate Taichan");
        FotoMakanan.add("https://www.piknikdong.com/wp-content/uploads/2020/08/Resep-Sate-Taichan.jpg");
        InfoMakanan.add("Sate taichan merupakan salah satu varian sate berbahan utama daging ayam yang dibakar tanpa baluran bumbu kacang atau kecap seperti pada sate pada umumnya..");
        HargaMakanan.add("Harga : Rp 20.000");

        NamaMakanan.add("Ayam Yakiniku");
        FotoMakanan.add("https://i.pinimg.com/originals/46/de/4d/46de4da5c2b212682d41b3a642d37561.jpg");
        InfoMakanan.add("Ayam yakiniku pada dasarnya adalah hidangan ayam yang dimasak dengan cara dipanggang atau dibakar. Kata yakiniku sendiri diambil dari Bahasa Jepang yang secara harfiah berarti daging panggang (yaki=bakar/panggang; niku=daging).Apr 24, 2017.");
        HargaMakanan.add("Harga : Rp 35.000");

        NamaMakanan.add("Beef Burger");
        FotoMakanan.add("https://upload.wikimedia.org/wikipedia/commons/thumb/0/0b/RedDot_Burger.jpg/1200px-RedDot_Burger.jpg");
        InfoMakanan.add("Hamburger (atau sering kali disebut dengan burger) adalah sejenis makanan berupa roti berbentuk bundar yang diiris dua dan di tengahnya diisi dengan patty yang biasanya diambil dari daging, kemudian sayur-sayuran berupa selada, tomat dan bawang bombay..");
        HargaMakanan.add("Harga : Rp 50.000");

        prosesRecyclerViewAdapter();
    }
}